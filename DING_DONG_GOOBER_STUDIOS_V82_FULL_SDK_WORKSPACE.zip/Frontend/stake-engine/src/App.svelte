<script lang="ts">
  import { onMount } from 'svelte';
  import GameStage from './GameStage.svelte';
  import { authenticate, play, launch, settleIfActive } from '../stakeEngineClient';
  import { parseReplay, fetchReplay } from '../replay';

  let stage: GameStage;
  let balance = '—';
  let currency = launch.currency;
  let bet = 1;
  let betLevels: number[] = [];
  let selectedMode = 'BASE';
  let busy = false;
  let status = 'Chargement du jeu…';
  let error = '';
  let replay = false;
  let replayState: Record<string, unknown> | null = null;
  let roundResult: Record<string, unknown> | null = null;
  let displayedWin = 0;
  let freeSpinsRemaining = 0;\n  let globalMultiplier = 1;

  onMount(async () => {
    try {
      const replayParams = parseReplay();
      if (replayParams) {
        replay = true;
        status = 'Replay chargé en lecture seule';
        const data = await fetchReplay(replayParams);
        replayState = data.state;
        roundResult = data;
        const replayEvents = (data as Record<string, unknown>).events ?? (data.state as Record<string, unknown>)?.events;
        if (Array.isArray(replayEvents)) await stage.playBookEvents(replayEvents);
        else stage?.showState(replayState);
        status = 'Replay prêt. Les contrôles de mise sont désactivés.';
        return;
      }
      const auth = await authenticate();
      balance = String(auth.balance.amount);
      currency = auth.balance.currency;
      betLevels = auth.config.betLevels;
      bet = auth.config.defaultBetLevel;
      status = auth.round?.active ? 'Une partie est en cours. Reprise à intégrer.' : 'Prêt à jouer';
      if (auth.round?.active) error = 'Une partie précédente est active. La reprise visuelle doit encore être connectée.';
    } catch (e) {
      error = e instanceof Error ? e.message : 'Erreur de connexion Stake Engine';
      status = 'Connexion impossible';
    }
  });

  async function spin() {
    if (busy || replay) return;
    busy = true;
    error = '';
    displayedWin = 0;
    freeSpinsRemaining = 0;\n    globalMultiplier = 1;
    roundResult = null;
    try {
      const result = await play(bet, selectedMode);
      balance = String(result.balance.amount);
      currency = result.balance.currency;
      const round = result.round as unknown as Record<string, unknown>;
      const events = round.events ?? (round.state as Record<string, unknown> | undefined)?.events;
      if (!Array.isArray(events)) {
        throw new Error('Le RGS n’a pas renvoyé de liste d’événements reconnue. Aucun résultat fictif ne sera affiché.');
      }
      status = 'Lecture des événements officiels…';
      const playback = await stage.playBookEvents(events);
      displayedWin = playback.finalWin;
      freeSpinsRemaining = playback.freeSpinsRemaining;
      globalMultiplier = playback.multiplier;
      status = `Tour affiché · ${playback.eventCount} événements`;
      const settled = await settleIfActive();
      if (settled?.balance) {
        balance = String(settled.balance.amount);
        currency = settled.balance.currency;
      }
      if (settled) status += ' · tour réglé';
    } catch (e) {
      error = e instanceof Error ? e.message : 'La mise a échoué';
      status = 'Erreur de traitement du tour';
    } finally {
      busy = false;
    }
  }
</script>

<svelte:head>
  <title>DING DONG | GOOBER STUDIOS</title>
  <meta name="description" content="DING DONG, la slot jungle de GOOBER STUDIOS." />
</svelte:head>

<main class="shell">
  <header class="topbar">
    <div class="brand"><span class="bell">🔔</span><div><strong>DING DONG</strong><small>GOOBER STUDIOS</small></div></div>
    {#if !replay}<div class="wallet"><small>SOLDE</small><strong>{balance} {currency}</strong></div>{/if}
  </header>

  <section class="hero">
    <div class="eyebrow">APERÇU VISUEL • WILD JUNGLE • CASCADES</div>
    <h1>LET THE JUNGLE <em>RING!</em></h1>
    <p>5 rouleaux · 6 rangées · Ways to Win</p>
  </section>

  <section class="game">
    <GameStage bind:this={stage}/>
    {#if replay}<div class="replay-label">MODE REPLAY · LECTURE SEULE</div>{/if}
    <div class="status">{status}</div>
    {#if displayedWin > 0}<div class="win-total">GAIN TOTAL : {displayedWin} <small>(unité du book SDK, conversion à confirmer)</small></div>{/if}
    {#if freeSpinsRemaining > 0 || globalMultiplier > 1}
      <div class="round-indicators">
        {#if freeSpinsRemaining > 0}<span>🎁 FREE SPINS RESTANTS : {freeSpinsRemaining}</span>{/if}
        {#if globalMultiplier > 1}<span>👑 MULTIPLICATEUR : ×{globalMultiplier}</span>{/if}
      </div>
    {/if}
    {#if error}<div class="error">{error}</div>{/if}
    {#if !replay}
      <div class="controls">
        <label>MISE
          <select bind:value={bet}>
            {#each betLevels as level}<option value={level}>{level}</option>{/each}
          </select>
        </label>
        <button class="spin" disabled={busy || betLevels.length === 0} onclick={spin}>
          {busy ? '…' : '🔔 SPIN'}
        </button>
      </div>
    {:else}
      <div class="replay-controls"><button class="spin" onclick={() => status = 'Rejouer : animation à connecter au moteur de replay.'}>▶ REVOIR</button></div>
    {/if}
  </section>

  <footer><span>RTP cible 96 % · Non certifié</span><span>GAIN MAX CIBLE 10 000× · Non validé</span></footer>
</main>
