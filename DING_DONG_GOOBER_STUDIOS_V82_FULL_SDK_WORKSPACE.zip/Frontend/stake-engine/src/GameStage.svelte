<script lang="ts">
  import { onMount } from 'svelte';
  import { Application, Container, Graphics, Text, TextStyle } from 'pixi.js';
  import { gsap } from 'gsap';

  type BookEvent = Record<string, any> & { type: string; index?: number };
  let host: HTMLDivElement;
  let app: Application | undefined;
  let reels: Container[] = [];
  let currentBoard: string[][] = [
    ['🐱','A','🐸','🔔','🐶','K'],
    ['🦆','🐶','Q','🐱','👑','A'],
    ['K','🐸','🦆','J','🐱','🔔'],
    ['🐶','A','👑','🐸','Q','🦆'],
    ['🔔','🐱','K','🐶','J','🐸']
  ];
  let highlighted = new Set<string>();
  let eventStatus = '';
  const symbols = ['🐱','🐶','🐸','🦆','👑','A','K','Q','J','🔔'];
  const colors = [0xffc34e,0x8ee58c,0x7ed8ff,0xffdc76,0xffd83e,0xfff2b0,0xfff2b0,0xfff2b0,0xfff2b0,0xff987d];

  function normalizeSymbol(raw: unknown): string {
    if (raw && typeof raw === 'object') {
      const item = raw as Record<string, unknown>;
      raw = item.name ?? item.symbol ?? item.id ?? '';
    }
    const value = String(raw).trim().toUpperCase();
    const map: Record<string,string> = {
      CAT:'🐱',DOG:'🐶',FROG:'🐸',DUCK:'🦆',
      H1:'🐱',H2:'🐶',H3:'🐸',H4:'🦆',
      A:'A',K:'K',Q:'Q',J:'J',L1:'A',L2:'K',L3:'Q',L4:'J',
      W:'👑',WILD:'👑',WILD_GOLDEN_CROWN:'👑',
      S:'🔔',SCATTER:'🔔',SCATTER_BELL:'🔔'
    };
    return map[value] ?? '';
  }

  function normalizeBoard(value: unknown): string[][] | null {
    if (!Array.isArray(value) || value.length !== 5) return null;
    const board = value.map((col: unknown) => {
      if (!Array.isArray(col) || col.length !== 6) return null;
      return col.map(normalizeSymbol);
    });
    if (board.some(col => !col || col.some((s: string) => !s))) return null;
    return board as string[][];
  }

  function extractBoardFromState(state: unknown): string[][] | null {
    if (!state || typeof state !== 'object') return null;
    const obj = state as Record<string, unknown>;
    for (const key of ['board','gameBoard','currentBoard','reelBoard']) {
      const board = normalizeBoard(obj[key]);
      if (board) return board;
    }
    for (const value of Object.values(obj)) {
      if (value && typeof value === 'object') {
        const found = extractBoardFromState(value);
        if (found) return found;
      }
    }
    return null;
  }

  function drawBoard() {
    if (!app) return;
    const stage = app.stage;
    stage.removeChildren();
    reels = [];
    const width = Math.min(host.clientWidth - 20, 760);
    const cell = Math.floor(Math.min((width - 30) / 5, 76));
    const gap = 5;
    const boardW = cell * 5 + gap * 4;
    const boardH = cell * 6 + gap * 5;
    const left = (app.screen.width - boardW) / 2;
    const top = Math.max(14, (app.screen.height - boardH) / 2);
    stage.addChild(
      new Graphics().roundRect(left - 13, top - 13, boardW + 26, boardH + 26, 24).fill({color:0x032d2b}),
      new Graphics().roundRect(left - 11, top - 15, boardW + 22, boardH + 30, 22).fill({color:0xffcf4f}).stroke({color:0xfff3a6,width:5}),
      new Graphics().roundRect(left - 5, top - 9, boardW + 10, boardH + 18, 17).fill({color:0x12644a}).stroke({color:0x63d77b,width:3})
    );

    for (let col = 0; col < 5; col++) {
      const reel = new Container();
      reel.x = left + col * (cell + gap);
      reel.y = top;
      for (let row = 0; row < 6; row++) {
        const symbol = currentBoard[col][row];
        const index = Math.max(0, symbols.indexOf(symbol));
        const tileY = row * (cell + gap);
        const wild = symbol === '👑';
        const scatter = symbol === '🔔';
        const tile = new Graphics().roundRect(0,tileY+2,cell,cell,13).fill({color:0x06483f})
          .roundRect(1,tileY,cell-2,cell-3,12).fill({color:wild?0xffd64e:scatter?0xff987d:0x16734f})
          .stroke({color:wild?0xfff4a0:0x72d987,width:2});
        const shine = new Graphics().roundRect(6,tileY+5,cell-12,5,3).fill({color:0xffffff,alpha:0.2});
        const label = new Text({text:symbol,style:new TextStyle({
          fontFamily:'Arial',fontSize:35,fontWeight:'bold',fill:colors[index],align:'center',
          stroke:{color:0x17432d,width:index<5?2:1},
          dropShadow:{color:0x002b20,alpha:0.45,blur:2,distance:2}
        })});
        label.anchor.set(0.5); label.x=cell/2; label.y=tileY+cell/2;
        reel.addChild(tile,shine,label);
        if (highlighted.has(`${col}:${row}`)) {
          reel.addChild(new Graphics().roundRect(2,tileY+2,cell-4,cell-7,12)
            .stroke({color:0xffffff,width:4}));
        }
      }
      stage.addChild(reel); reels.push(reel);
    }
  }

  function extractWinPositions(ev: BookEvent): Set<string> {
    const result = new Set<string>();
    const wins = Array.isArray(ev.wins) ? ev.wins : [];
    for (const win of wins) {
      const positions = Array.isArray(win.positions) ? win.positions : (Array.isArray(win.position) ? win.position : []);
      for (const pos of positions) {
        if (Array.isArray(pos) && pos.length >= 2 &&
            Number.isInteger(Number(pos[0])) && Number.isInteger(Number(pos[1]))) {
          const c = Number(pos[0]), r = Number(pos[1]);
          if (c >= 0 && c < 5 && r >= 0 && r < 6) result.add(`${c}:${r}`);
        } else if (pos && typeof pos === 'object') {
          const p = pos as Record<string, unknown>;
          const c = Number(p.reel ?? p.column ?? p.x);
          const r = Number(p.row ?? p.y);
          if (Number.isInteger(c) && Number.isInteger(r) && c>=0 && c<5 && r>=0 && r<6) result.add(`${c}:${r}`);
        }
      }
    }
    return result;
  }

  async function animateReveal(board: string[][]) {
    currentBoard = board;
    highlighted.clear();
    drawBoard();
    reels.forEach((reel, i) => {
      reel.alpha = 0.5;
      gsap.to(reel, {alpha:1, duration:0.18, delay:i*0.07, ease:'back.out(1.6)'});
    });
    await new Promise(resolve => setTimeout(resolve, 520));
  }


  function eventNumber(ev: BookEvent, keys: string[], fallback = 0): number {
    for (const key of keys) {
      if (ev[key] === undefined || ev[key] === null || ev[key] === '') continue;
      const value = Number(ev[key]);
      if (Number.isFinite(value)) return value;
    }
    return fallback;
  }

  function safeCounter(value: number, fallback: number): number {
    return Number.isFinite(value) && value >= 0 ? Math.floor(value) : fallback;
  }

  async function showBanner(text: string, color = 0xffef78, hold = 520) {
    if (!app) return;
    const banner = new Container();
    const bg = new Graphics().roundRect(-150, -29, 300, 58, 18)
      .fill({color:0x063e34, alpha:0.96})
      .stroke({color:0xffdf63,width:4});
    const label = new Text({text, style:new TextStyle({
      fontFamily:'Arial',fontSize:25,fontWeight:'bold',fill:color,
      stroke:{color:0x4d2b13,width:4},align:'center'
    })});
    label.anchor.set(0.5);
    banner.addChild(bg,label);
    banner.x = app.screen.width / 2;
    banner.y = 38;
    app.stage.addChild(banner);
    banner.alpha = 0;
    banner.scale.set(0.7);
    await new Promise<void>(resolve => {
      gsap.to(banner, {alpha:1,duration:0.18});
      gsap.to(banner.scale, {x:1,y:1,duration:0.25,ease:'back.out(2)',onComplete:resolve});
    });
    await new Promise(resolve => setTimeout(resolve, hold));
    await new Promise<void>(resolve => gsap.to(banner,{alpha:0,duration:0.2,onComplete:resolve}));
    banner.destroy({children:true});
  }

  async function animateTumble(ev: BookEvent) {
    const positions = extractWinPositions(ev);
    highlighted = positions;
    drawBoard();
    // The SDK's tumble event is the visual cue that winning symbols are removed.
    const active = [...reels];
    active.forEach((reel, i) => {
      gsap.to(reel, {alpha:0.28, y:reel.y+7, duration:0.16, yoyo:true, repeat:1, delay:i*0.025});
    });
    await new Promise(resolve => setTimeout(resolve, 420));
    highlighted.clear();
    const board = normalizeBoard(ev.board ?? ev.newBoard ?? ev.updatedBoard);
    if (board) {
      await animateReveal(board);
    } else {
      // Wait for the following reveal event to provide the authoritative refilled board.
      drawBoard();
    }
  }

  export async function playBookEvents(input: unknown): Promise<{finalWin:number, eventCount:number, freeSpinsRemaining:number, multiplier:number}> {
    if (!Array.isArray(input)) throw new Error('La réponse RGS ne contient pas de liste events exploitable.');
    const events = input.filter((item): item is BookEvent =>
      !!item && typeof item === 'object' && typeof (item as Record<string, unknown>).type === 'string'
    ) as BookEvent[];
    // The book array is already authoritative. Sort only when every event has a numeric index;
    // otherwise preserve source order instead of moving unindexed events to the front.
    if (events.length > 0 && events.every(ev => Number.isFinite(Number(ev.index)))) {
      events.sort((a,b) => Number(a.index) - Number(b.index));
    }
    let finalWin = 0;
    let freeSpinsRemaining = 0;
    let multiplier = 1;

    for (const ev of events) {
      if (!ev || typeof ev.type !== 'string') continue;
      const type = ev.type;
      eventStatus = type;

      if (type === 'reveal' || type === 'spin') {
        const board = normalizeBoard(ev.board);
        if (board) await animateReveal(board);
        const gameType = String(ev.gameType ?? '').toLowerCase();
        if (gameType.includes('free')) await showBanner('FREE SPINS', 0xffe56b, 350);
      } else if (type === 'winInfo' || type === 'win' || type === 'waysWin') {
        highlighted = extractWinPositions(ev);
        drawBoard();
        const amount = eventNumber(ev, ['totalWin','win','amount'], 0);
        const symbol = String(ev.wins?.[0]?.symbol ?? '');
        await showBanner(amount > 0 ? `WIN ${amount.toFixed(2)} ${symbol}` : 'WIN!', 0xfff19a, 440);
      } else if (type === 'tumbleBanner' || type.toLowerCase().includes('tumble') || type.toLowerCase().includes('cascade')) {
        const tumbleWin = eventNumber(ev, ['tumbleWin','totalTumbleWin','win','amount'], 0);
        await showBanner(tumbleWin > 0 ? `CASCADE +${tumbleWin.toFixed(2)}` : 'CASCADE!', 0x9dff9d, 360);
        await animateTumble(ev);
      } else if (type === 'freeSpinTrigger' || type === 'fsTrigger' || type === 'freegameTrigger') {
        freeSpinsRemaining = safeCounter(eventNumber(ev, ['count','totalFreeSpins','freeSpins'], freeSpinsRemaining), freeSpinsRemaining);
        await showBanner(`🎉 ${freeSpinsRemaining} FREE SPINS`, 0xffe56b, 900);
      } else if (type === 'updateFreeSpin' || type === 'updateFreeSpins' || type === 'freespinUpdate') {
        freeSpinsRemaining = safeCounter(eventNumber(ev, ['spinsRemaining','remaining','count'], freeSpinsRemaining), freeSpinsRemaining);
        await showBanner(`FREE SPINS : ${freeSpinsRemaining}`, 0xffe56b, 400);
      } else if (type === 'updateGlobalMult' || type === 'updateMultiplier' || type.toLowerCase().includes('mult')) {
        multiplier = eventNumber(ev, ['globalMult','multiplier','value','mult'], multiplier);\n        if (!Number.isFinite(multiplier) || multiplier < 1) multiplier = 1;
        await showBanner(`MULTIPLICATEUR ×${multiplier}`, 0xffe56b, 650);
      } else if (type === 'setWin' || type === 'setTotalWin' || type === 'finalWin') {
        const amount = eventNumber(ev, ['totalWin','win','amount','finalWin'], 0);
        if (Number.isFinite(amount)) finalWin = amount;
        await showBanner(`GAIN TOTAL ${finalWin.toFixed(2)}`, 0xffe56b, 650);
      } else {
        // Unknown events are intentionally ignored visually, but retained in eventCount.
      }
    }
    highlighted.clear();
    drawBoard();
    return {finalWin, eventCount:events.length, freeSpinsRemaining, multiplier};
  }

  export function showState(state: unknown): boolean {
    const board = extractBoardFromState(state);
    if (!board) return false;
    currentBoard = board; highlighted.clear(); drawBoard(); return true;
  }

  onMount(() => {
    let disposed = false;
    (async () => {
      app = new Application();
      await app.init({background:0x0b5945,antialias:true,resizeTo:host,resolution:Math.min(window.devicePixelRatio||1,2),autoDensity:true});
      if (disposed) { app.destroy(true); return; }
      host.appendChild(app.canvas); drawBoard();
    })();
    const resize = () => drawBoard();
    window.addEventListener('resize',resize);
    return () => {disposed=true;window.removeEventListener('resize',resize);app?.destroy(true);app=undefined;};
  });
</script>
<div class="stage" bind:this={host} aria-label="Grille cartoon DING DONG"></div>
