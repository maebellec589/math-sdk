/**
 * DING DONG — Stake Engine RGS integration.
 * Built against the public engineio/ts-client API contract.
 */
import { RGSClient } from "stake-engine";
import type {
  AuthenticateResponse,
  PlayResponse,
  Round,
  Balance,
} from "stake-engine";

const query = new URLSearchParams(window.location.search);
const replayMode = query.get("replay") === "true";

export const launch = {
  sessionID: query.get("sessionID"),
  rgs_url: query.get("rgs_url"),
  lang: query.get("lang") ?? "en",
  currency: query.get("currency") ?? "USD",
  device: query.get("device") ?? "desktop",
  social: query.get("social") === "true",
  demo: query.get("demo") === "true",
  replay: replayMode,
};

if (!replayMode && (!launch.sessionID || !launch.rgs_url)) {
  throw new Error("Stake Engine launch URL must include sessionID and rgs_url.");
}

if (!replayMode && launch.device !== "desktop" && launch.device !== "mobile") {
  throw new Error(`Unsupported device value: ${launch.device}`);
}

export const rgs = replayMode ? null : RGSClient({ url: window.location.href });

let authenticated = false;
let activeRound: Round | null = null;

export async function authenticate(): Promise<AuthenticateResponse> {
  if (!rgs) throw new Error("Replay mode is read-only.");
  const response = await rgs.Authenticate();
  authenticated = true;
  activeRound = response.round;
  return response;
}

export function getActiveRound() {
  return activeRound;
}

export async function play(amount: number, mode: string): Promise<PlayResponse> {
  if (!rgs || !authenticated) throw new Error("Authenticate before playing.");
  if (activeRound?.active) throw new Error("A round is already active.");
  const response = await rgs.Play({ amount, mode });
  activeRound = response.round;
  return response;
}

/** Only call when the RGS reports an active round and its animation is complete. */
export async function endRound() {
  if (!rgs || !authenticated) throw new Error("Authenticate before ending a round.");
  if (!activeRound?.active) throw new Error("There is no active round to settle.");
  const response = await rgs.EndRound();
  activeRound = null;
  return response;
}

export async function sendGameEvent(event: string) {
  if (!rgs || !authenticated) throw new Error("Authenticate before sending events.");
  return rgs.Event(event);
}

export function onBalance(callback: (balance: Balance) => void) {
  const handler = (event: Event) => callback((event as CustomEvent<Balance>).detail);
  window.addEventListener("balanceUpdate", handler);
  return () => window.removeEventListener("balanceUpdate", handler);
}

export function onRoundActive(callback: (active: boolean) => void) {
  const handler = (event: Event) => callback((event as CustomEvent<{active:boolean}>).detail.active);
  window.addEventListener("roundActive", handler);
  return () => window.removeEventListener("roundActive", handler);
}


/**
 * Settle only after the frontend has finished consuming the authoritative book events.
 * Returns null when the RGS says the round is already closed.
 */
export async function settleIfActive() {
  if (!rgs || !authenticated) throw new Error("Authenticate before ending a round.");
  if (!activeRound?.active) return null;
  const response = await rgs.EndRound();
  activeRound = null;
  return response;
}
