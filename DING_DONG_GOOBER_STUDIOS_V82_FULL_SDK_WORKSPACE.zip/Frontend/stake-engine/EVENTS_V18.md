# V18 — Événements officiels Stake Engine

La documentation officielle du Math SDK décrit des books composés d'événements `{index, type, ...}`. L'exemple de quick start montre notamment `reveal` (plateau), `winInfo` (wins/positions), puis des événements de fin de gain. La documentation des jeux exemples mentionne aussi `tumbleBanner` pour les séquences de tumble et les événements de compteurs Free Spins / multiplicateurs.

## Ajouts du frontend
- `reveal` : plateau officiel 5×6 et apparition séquencée par rouleau.
- `winInfo` : surbrillance des positions gagnantes et bannière de gain.
- `tumbleBanner` / événements contenant `tumble` ou `cascade` : bannière de cascade, effet visuel de retrait, puis lecture du board mis à jour si l'événement le fournit.
- `freeSpinTrigger` : bannière d'attribution des Free Spins.
- `updateFreeSpin` : affichage du compteur restant.
- `updateGlobalMult` : affichage du multiplicateur global.
- `setWin`, `setTotalWin`, `finalWin` : affichage du gain total.
- Le parseur accepte `positions` et `position` pour les positions gagnantes.

## Limites
- Les noms exacts des événements personnalisés DING DONG et les champs de leur payload doivent être confirmés dans les books réellement générés par le SDK.
- Un événement tumble peut annoncer une cascade sans contenir le plateau refait. Dans ce cas le frontend attend le prochain `reveal` officiel; il ne calcule pas lui-même les symboles tombés.
- La logique d'affichage du gain est une présentation en unités de mise si les événements utilisent les valeurs de payoutMultiplier documentées. Le format monétaire final doit être confirmé.
- Aucun build npm/Vite, test RGS ou test de replay réel n'a été exécuté ici.
