# V16 — Rendu de l’état RGS

- La grille de démonstration est désormais fixe et ne prétend plus être un tirage RGS.
- `GameStage.showState(state)` recherche une grille 5×6 dans `board`, `gameBoard`, `currentBoard` ou `reelBoard`, y compris dans les objets imbriqués.
- Les codes H1-H4, L1-L4, W et S sont mappés vers les symboles cartoon.
- Après Play ou chargement du replay, l'application tente d'afficher le plateau retourné.
- Si la structure reçue n'est pas reconnue, aucun résultat inventé n'est affiché.

Limites : la forme réelle de `round.state` reste à confirmer avec un book ou une session RGS. Les cascades, événements, multiplicateurs et Free Spins ne sont pas animés. `EndRound()` reste suspendu. Aucun build npm/Vite ni test RGS n'a été exécuté.
