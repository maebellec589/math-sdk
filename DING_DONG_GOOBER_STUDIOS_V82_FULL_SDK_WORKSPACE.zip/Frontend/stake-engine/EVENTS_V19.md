# V19 — Suivi des événements et unités

- Le lecteur retourne désormais `finalWin`, `eventCount`, `freeSpinsRemaining` et `multiplier`.
- Les compteurs Free Spins et multiplicateur global sont affichés dans l'interface après la lecture du book.
- Les gains ne sont plus suffixés par `×` par défaut. Le format numérique d'un événement ne suffit pas à déterminer s'il s'agit d'une devise, d'une fraction de mise ou d'une valeur en centièmes.
- La conversion en solde/devise doit être faite uniquement après confirmation du schéma exact de l'événement dans un book généré et du contrat RGS.
- Les champs alternatifs restent provisoires et devront être resserrés sur les payloads réellement produits par le SDK.
