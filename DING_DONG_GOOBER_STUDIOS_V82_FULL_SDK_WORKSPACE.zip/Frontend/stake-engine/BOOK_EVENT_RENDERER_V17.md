# V17 — Lecture séquentielle des Book Events

## Base technique
La documentation publique du Math SDK indique que les résultats d'un book sont constitués d'un tableau `events`, ordonné par `index`. Le RGS renvoie le contenu des événements au frontend. Les événements documentés comprennent notamment `reveal`, `winInfo`, `setWin`, `setTotalWin` et `finalWin`.

## Implémentation
- L'application lit `round.events`, avec fallback sur `round.state.events`.
- Le moteur visuel trie les événements par `index` et les consomme séquentiellement.
- `reveal` / `spin` : affiche un plateau 5×6 quand le format du board est reconnu.
- `winInfo` / `win` / `waysWin` : surligne les positions au format coordonnée [reel,row] ou objet {reel,row}.
- `setWin`, `setTotalWin`, `finalWin` : récupère le dernier montant fourni.
- Les événements de Free Spins et multiplicateur sont temporisés mais ne disposent pas encore de widgets dédiés.
- Le tour est réglé avec `EndRound()` uniquement après la fin du playback et si le client indique que le tour est encore actif.

## Limites explicites
- Les positions des wins sont dessinées uniquement si leur format est [reel,row] ou {reel,row}. Les autres formats sont ignorés plutôt que devinés.
- Les événements spécifiques aux cascades, bonus, retriggers et multiplicateurs doivent être confirmés à partir d'un book DING DONG réel.
- Le replay endpoint renvoie `state`; le code ne peut animer les événements que si `state.events` est présent.
- Pas de compilation Vite/Svelte ni test RGS réel exécuté ici.
- Le rendu du board est limité au format de jeu configuré en 5×6.
