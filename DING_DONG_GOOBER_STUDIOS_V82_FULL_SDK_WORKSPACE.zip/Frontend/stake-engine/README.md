# DING DONG — Stake Engine frontend scaffold

Built against the public `engineio/ts-client` source and current Stake Engine frontend documentation.

## Stack
- Svelte 5 + Vite, static output only
- PixiJS 8 stage
- GSAP timeline
- Official `stake-engine` client
- Read-only Bet Replay loader

## Run locally
Requires Node.js 20+ and npm:
```bash
npm install
npm run dev
npm run check
npm run build
```

## Critical current limitations
This is a frontend scaffold, not a submission-ready game.

- The PixiJS grid is currently a visual preview with random symbols. It does NOT show the authoritative RGS outcome.
- `Play()` returns `{ balance, round }`; the outcome is in `round.state`, not in a top-level `events` array. The code now follows this documented response shape.
- The actual game-state event schema must be mapped from the SDK-generated book and rendered in order. Until then, preview spins must never be represented as the real bet result.
- Active-round recovery is detected after authentication but the visual replay/resume sequence is not implemented.
- Bet replay data is fetched from the documented endpoint, but the state-to-animation renderer is still pending.
- The bet selector currently displays raw API bet amounts. It must be formatted using the official helper and currency precision.
- The `stake-engine` package types and production build still need to be checked by installing dependencies in a Node environment and running `npm run check` and `npm run build`.
- No real RGS session has been used.

## Official sources
- https://github.com/engineio/ts-client
- https://github.com/engineio/docs
- https://stake-engine.com/docs/architecture/frontend-stack
- https://stake-engine.com/docs/api/play
- https://stake-engine.com/docs/api/bet-replay
