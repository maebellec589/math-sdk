# V20 — Robustesse du lecteur de books

- Les entrées non structurées sont ignorées sans interrompre la lecture.
- Le tri par index est effectué uniquement lorsque tous les événements ont un index numérique; autrement l'ordre du book est conservé.
- Les valeurs numériques vides ou nulles ne sont plus confondues avec zéro.
- Les compteurs Free Spins et multiplicateurs sont sécurisés contre les valeurs invalides.
- Le contrat replay expose les champs de payout comme optionnels; leur unité n'est pas présumée.
