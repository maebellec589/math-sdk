# DING DONG — Cartoon art direction

## Visual identity
A bright jungle adventure with a playful Saturday-morning-cartoon feel. The interface should feel like a polished toy/game-show set, not a dark casino dashboard.

- Deep teal and leafy green jungle backdrop with subtle dotted texture.
- Golden-yellow title lettering, chunky rounded display font, dark offset shadow.
- Warm yellow/orange cabinet frame with cream highlights and thick rounded corners.
- Reel cells in saturated jungle green with mint outlines and soft highlights.
- Animals are expressive, friendly, oversized focal points; the golden crown Wild gets a gold treatment.
- Large tactile spin button with a raised toy-like shadow and a small press animation.
- High contrast and large touch targets for mobile.

## Current implementation status
The V14 frontend applies the cartoon visual direction to the shell and PixiJS reel tiles. Symbol artwork is still emoji placeholders, and the board currently randomizes a visual preview. It is not yet rendering authoritative RGS outcomes. Replace emoji placeholders with commissioned/original illustrated symbol assets and connect the canonical RGS state renderer before release.
