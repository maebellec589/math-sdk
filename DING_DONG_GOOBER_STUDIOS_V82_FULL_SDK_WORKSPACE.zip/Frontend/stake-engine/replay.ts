/**
 * Read-only replay mode. Stake's documentation specifies:
 * GET https://{rgs_url}/bet/replay/{game}/{version}/{mode}/{event}
 */
export type ReplayParams = {
  game: string;
  version: string;
  mode: string;
  event: string;
  rgs_url: string;
  currency?: string;
  amount?: string;
  lang?: string;
  device?: string;
  social?: string;
};

export function parseReplay(search = window.location.search): ReplayParams | null {
  const p = new URLSearchParams(search);
  if (p.get("replay") !== "true") return null;
  const required = ["game", "version", "mode", "event", "rgs_url"] as const;
  for (const key of required) {
    if (!p.get(key)) throw new Error(`Missing replay parameter: ${key}`);
  }
  return {
    game: p.get("game")!,
    version: p.get("version")!,
    mode: p.get("mode")!,
    event: p.get("event")!,
    rgs_url: p.get("rgs_url")!,
    currency: p.get("currency") ?? undefined,
    amount: p.get("amount") ?? undefined,
    lang: p.get("lang") ?? undefined,
    device: p.get("device") ?? undefined,
    social: p.get("social") ?? undefined,
  };
}

export async function fetchReplay(params: ReplayParams) {
  const host = params.rgs_url.replace(/^https?:\/\//, "").replace(/\/+$/, "");
  const url = `https://${host}/bet/replay/${encodeURIComponent(params.game)}/${encodeURIComponent(params.version)}/${encodeURIComponent(params.mode)}/${encodeURIComponent(params.event)}`;
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Replay request failed: HTTP ${response.status}`);
  return response.json() as Promise<{
    payoutMultiplier?: number;
    costMultiplier?: number;
    state: Record<string, unknown>;
    events?: unknown[];
  }>;
}
