# DING DONG – GOOBER STUDIOS | V82

Ce paquet contient le dépôt complet du Math SDK fourni par l'utilisateur, le jeu `games/goober_ding_dong` intégré, ainsi que le frontend Svelte séparé.

## Important
- Le préflight confirme la configuration 5×6, le plafond 10 000× et les multiplicateurs d'achat : Normal 100×, Super 200×, Mystery 250×, Bonus Hunt 3×, Wild Feature 20×.
- La dépendance Python `zstandard` n'est pas disponible dans l'environnement actuel. Le préflight s'arrête donc avant la génération des books.
- Aucun book officiel n'est inclus ou prétendu généré.
- La compilation frontend et les tests RGS ne sont pas encore exécutés.
- Le RTP 96 % est un objectif de configuration, pas une mesure certifiée pour les prix d'achat actuels.

## Structure
- `StakeEngine_MathSDK/` : dépôt SDK complet, avec le jeu dans `games/goober_ding_dong/`.
- `Frontend/` : sources frontend Svelte et client Stake Engine.

## Préflight
Depuis la racine `StakeEngine_MathSDK/` :

```bash
python games/goober_ding_dong/preflight.py
```

Le préflight attend `numpy`, `pandas`, `scipy` et `zstandard`. Pour installer les dépendances dans un environnement connecté, utiliser le `requirements.txt` du SDK.

Ne pas importer ce paquet tel quel dans Engine Studio : il s'agit d'un espace de travail de développement, pas des dossiers finaux d'export Math/Frontend.
