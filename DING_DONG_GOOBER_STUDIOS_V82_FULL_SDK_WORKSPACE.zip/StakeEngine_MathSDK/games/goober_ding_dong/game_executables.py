"""DING DONG Ways evaluation integrated with SDK tumble symbols."""
from game_calculations import GameCalculations
from src.calculations.ways import Ways
from src.events.events import fs_trigger_event, reveal_event
from freespin_awards import resolve_freespin_award
from wild_feature_squares import apply_two_random_wilds


class GameExecutables(GameCalculations):

    def draw_board(self, emit_event=True, trigger_symbol="scatter"):
        """Draw through the SDK, then apply the bought Wild Feature before reveal."""
        # Stake Engine's native draw_board supports suppressing the reveal event.
        super().draw_board(emit_event=False, trigger_symbol=trigger_symbol)
        if self.betmode == "wild_feature" and self.criteria == "two_wild_squares_x2":
            # Spawn two single-cell Wilds at fresh random positions on this
            # feature board. GameState removes this pair before each tumble
            # and spawns a new random pair on the next cascade board.
            self.wild_feature_positions = apply_two_random_wilds(
                self.board, self.create_symbol, rng=getattr(self, "_wild_rng", None)
            )
            self.get_special_symbols_on_board()
        if emit_event:
            reveal_event(self)

    def check_fs_condition(self, scatter_key="scatter"):
        """Mystery outcomes are preselected by the SDK distribution criteria."""
        if self.betmode == "mystery" and self.criteria in {
            "mystery_hidden_5fs", "mystery_super_15fs"
        }:
            return True
        return super().check_fs_condition(scatter_key)

    def check_freespin_entry(self, scatter_key="scatter"):
        """Accept the SDK-selected Mystery feature outcome even if the forced board has no natural trigger."""
        if self.betmode == "mystery" and self.criteria in {
            "mystery_hidden_5fs", "mystery_super_15fs"
        }:
            return True
        return super().check_freespin_entry(scatter_key)

    def update_freespin_amount(self, scatter_key="scatter"):
        """Award the configured 3/4/5+ tier without indexing errors on 6+ scatters."""
        scatter_count = self.count_special_symbols(scatter_key)
        self.tot_fs = resolve_freespin_award(
            self.criteria, scatter_count, self.gametype, self.config.freespin_triggers
        )
        if self.tot_fs <= 0:
            return
        fs_trigger_event(
            self,
            basegame_trigger=(self.gametype == self.config.basegame_type),
            freegame_trigger=(self.gametype == self.config.freegame_type),
        )

    def evaluate_ways_board(self, apply_current_multiplier=False):
        """Calculate ways, mark all paid positions for the SDK tumble engine."""
        multiplier = self.global_multiplier if apply_current_multiplier else 1
        self.win_data = Ways.get_ways_data(
            self.config,
            self.board,
            global_multiplier=multiplier,
            multiplier_strategy="global",
        )
        if self.win_data["totalWin"] > 0:
            for win in self.win_data["wins"]:
                for pos in win["positions"]:
                    self.board[pos["reel"]][pos["row"]].explode = True
            Ways.record_ways_wins(self)
            self.win_manager.update_spinwin(self.win_data["totalWin"])
        self.win_manager.tumble_win = self.win_data["totalWin"]
