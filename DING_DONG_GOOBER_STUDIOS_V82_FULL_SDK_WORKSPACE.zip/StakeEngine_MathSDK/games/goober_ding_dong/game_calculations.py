from src.executables.executables import Executables


class GameCalculations(Executables):
    """DING DONG-specific calculations are implemented in GameExecutables."""
    pass
