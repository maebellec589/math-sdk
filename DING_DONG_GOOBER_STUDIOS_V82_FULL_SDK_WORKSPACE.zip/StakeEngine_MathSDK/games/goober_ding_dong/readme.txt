DING DONG - GOOBER STUDIOS
Stake Engine Math SDK integration draft

Based on the SDK source archive supplied by the user (math-sdk-main, commit 141b4e89065ac4400769709a919259a923430c4d).

This package is an integration scaffold, NOT production-ready. It preserves user pricing (base=1x, Normal=100x, Super=200x, Mystery=250x) and the prototype game rules, but book generation is gated until the SDK game-state smoke tests, mode semantics, RTP optimization, and RGS tests pass.
