# DING DONG V80 - SDK preflight status

## Verified in this environment
- SDK game-state smoke test: 9/9 deterministic cases passed.
- Board configuration: 5 reels x 6 rows.
- Bet modes loaded: base, bonus_normal, bonus_super, mystery, bonus_hunt, wild_feature.
- User-selected buy prices preserved: Normal 100x, Super 200x, Mystery 250x at a 1x base bet.
- Reel CSV files BR0 and FR0 are present.

The smoke test was run with a temporary import-only `zstandard` stub because the real package is unavailable in this runtime. The stub deliberately raises if compression/decompression is invoked. Therefore this test does NOT generate books and is NOT a substitute for the real SDK runtime.

## Blockers
- Python package `zstandard` is not installed in the execution environment.
- Official compressed book generation has not run.
- Optimization and statistical analysis have not run for all six bet modes.
- Frontend build and live RGS wallet integration have not been tested.
- Stake Engine approval has not been requested or granted.

## Safe next command
From the SDK root, after installing requirements in a network-enabled Python 3.12+ environment:

```bash
python games/goober_ding_dong/preflight.py
python games/goober_ding_dong/tests/sdk_smoke_test.py
```

Do not submit books or claim publication readiness until real SDK book generation, format checks, RTP analysis, frontend build, and RGS validation pass.
