"""DING DONG preflight checks. Safe to run before any production book generation."""
from __future__ import annotations
import importlib.util
import json
import sys
from pathlib import Path

GAME_DIR = Path(__file__).resolve().parent
SDK_ROOT = GAME_DIR.parents[1]
sys.path.insert(0, str(GAME_DIR))
sys.path.insert(0, str(SDK_ROOT))

REQUIRED = ("numpy", "pandas", "scipy", "zstandard")

def main() -> int:
    missing = [name for name in REQUIRED if importlib.util.find_spec(name) is None]
    from game_config import GameConfig
    config = GameConfig()
    names = [mode.get_name() for mode in config.bet_modes]
    expected = ["base", "bonus_normal", "bonus_super", "mystery", "bonus_hunt", "wild_feature"]
    assert names == expected, f"Unexpected bet modes: {names}"
    assert config.num_reels == 5 and config.num_rows == [6] * 5
    assert config.wincap == 10000 and config.rtp == 0.96
    prices = {mode.get_name(): mode.get_cost() for mode in config.bet_modes}
    assert prices["bonus_normal"] == 100
    assert prices["bonus_super"] == 200
    assert prices["mystery"] == 250
    assert prices["bonus_hunt"] == 3
    assert prices["wild_feature"] == 20
    for reel in ("BR0.csv", "FR0.csv"):
        path = GAME_DIR / "reels" / reel
        assert path.is_file() and path.stat().st_size > 0, f"Missing reel file: {reel}"
    report = {
        "game": config.game_name,
        "game_id": config.game_id,
        "board": "5x6",
        "rtp_target_only": config.rtp,
        "wincap": config.wincap,
        "bet_modes": prices,
        "missing_runtime_dependencies": missing,
        "books_generated": False,
        "official_rgs_validated": False,
    }
    out = GAME_DIR / "PREFLIGHT_V80.json"
    out.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    if missing:
        print("PREFLIGHT BLOCKED: install missing runtime dependencies before SDK books.")
        return 2
    print("PREFLIGHT PASS: dependencies and static game configuration are present.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
