import os
from src.config.config import Config
from src.config.betmode import BetMode
from src.config.distributions import Distribution

class GameConfig(Config):
    """DING DONG SDK configuration scaffold. Validate against current SDK."""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        super().__init__()
        self.game_id = "goober_ding_dong"
        self.provider_name = "GOOBER STUDIOS"
        self.provider_number = 0
        self.game_name = "DING DONG"
        self.working_name = "DING DONG - GOOBER STUDIOS"
        self.win_type = "ways"
        self.rtp = 0.96  # target only; prototype calibration is not SDK certification
        self.wincap = 10000
        self.construct_paths()

        self.num_reels = 5
        self.num_rows = [6] * self.num_reels

        # H1-H4 premium animals; L1-L4 card symbols.
        self.paytable = {
            (3, "H1"): 0.003008078325,
            (4, "H1"): 0.00751802175,
            (5, "H1"): 0.0199225287,
            (3, "H2"): 0.002518346025,
            (4, "H2"): 0.00627734565,
            (5, "H2"): 0.0175543893,
            (3, "H3"): 0.0022549716,
            (4, "H3"): 0.00552642435,
            (5, "H3"): 0.015036043275,
            (3, "H4"): 0.0019937826,
            (4, "H4"): 0.0049996755,
            (5, "H4"): 0.0137975526,
            (3, "L1"): 0.0011274858,
            (4, "L1"): 0.002518346025,
            (5, "L1"): 0.00627734565,
            (3, "L2"): 0.001014295725,
            (4, "L2"): 0.0022549716,
            (5, "L2"): 0.00552642435,
            (3, "L3"): 0.0007509213,
            (4, "L3"): 0.00176740245,
            (5, "L3"): 0.0042487542,
            (3, "L4"): 0.00063991665,
            (4, "L4"): 0.0015040503,
            (5, "L4"): 0.0034956477,
        }
        self.include_padding = True
        self.special_symbols = {"wild": ["W"], "scatter": ["S"], "multiplier": []}
        # SDK indexes this mapping by the exact scatter count. The reels are
        # forced to at most one scatter per reel for feature entries (max 5).
        self.freespin_triggers = {
            self.basegame_type: {3: 10, 4: 15, 5: 20},
            self.freegame_type: {3: 10, 4: 15, 5: 20},
        }
        self.anticipation_triggers = {
            self.basegame_type: 2,
            self.freegame_type: 2,
        }

        self.reels = {
            "BR0": self.read_reels_csv(os.path.join(self.reels_path, "BR0.csv")),
            "FR0": self.read_reels_csv(os.path.join(self.reels_path, "FR0.csv")),
        }

        # Bet modes are priced as multiples of the base bet.
        # These are proposed design prices, not approved/certified RTP values.
        # Each mode requires its own generated books and lookup table.
        base_distributions = [
            Distribution(
                criteria="freegame",
                quota=0.10,
                conditions={
                    "reel_weights": {
                        self.basegame_type: {"BR0": 1},
                        self.freegame_type: {"FR0": 1},
                    },
                    "scatter_triggers": {3: 100, 4: 20, 5: 5},
                    "force_wincap": False,
                    "force_freegame": True,
                },
            ),
            Distribution(
                criteria="0",
                quota=0.40,
                win_criteria=0.0,
                conditions={
                    "reel_weights": {self.basegame_type: {"BR0": 1}},
                    "force_wincap": False,
                    "force_freegame": False,
                },
            ),
            Distribution(
                criteria="basegame",
                quota=0.50,
                conditions={
                    "reel_weights": {self.basegame_type: {"BR0": 1}},
                    "force_wincap": False,
                    "force_freegame": False,
                },
            ),
        ]

        def bought_freegame_distribution(criteria, free_spins, quota=1.0):
            # The force_freegame flag enters the freegame pipeline. The exact
            # fixed spin-count override must be implemented in GameState after
            # the SDK distribution/criteria selection is confirmed.
            return Distribution(
                criteria=criteria,
                quota=quota,
                conditions={
                    "reel_weights": {
                        self.basegame_type: {"BR0": 1},
                        self.freegame_type: {"FR0": 1},
                    },
                    "force_wincap": False,
                    "force_freegame": True,
                    "scatter_triggers": {3: 100},
                },
            )

        self.bet_modes = [
            BetMode(
                name="base", cost=1.0, rtp=self.rtp, max_win=self.wincap,
                auto_close_disabled=False, is_feature=True, is_buybonus=False,
                distributions=base_distributions,
            ),
            BetMode(
                name="bonus_normal", cost=100.0, rtp=self.rtp, max_win=self.wincap,
                auto_close_disabled=False, is_feature=False, is_buybonus=True,
                distributions=[bought_freegame_distribution("normal_10fs", 10)],
            ),
            BetMode(
                name="bonus_super", cost=200.0, rtp=self.rtp, max_win=self.wincap,
                auto_close_disabled=False, is_feature=False, is_buybonus=True,
                distributions=[bought_freegame_distribution("super_15fs", 15)],
            ),
            BetMode(
                name="mystery", cost=250.0, rtp=self.rtp, max_win=self.wincap,
                auto_close_disabled=False, is_feature=False, is_buybonus=True,
                distributions=[
                    bought_freegame_distribution("mystery_hidden_5fs", 5, quota=0.10),
                    bought_freegame_distribution("mystery_super_15fs", 15, quota=0.40),
                    Distribution(
                        criteria="mystery_empty", quota=0.50, win_criteria=0.0,
                        conditions={
                            "reel_weights": {self.basegame_type: {"BR0": 1}},
                            "force_wincap": False,
                            "force_freegame": False,
                        },
                    ),
                ],
            ),
            BetMode(
                name="bonus_hunt", cost=3.0, rtp=self.rtp, max_win=self.wincap,
                auto_close_disabled=False, is_feature=True, is_buybonus=False,
                distributions=[
                    Distribution(
                        criteria="hunt_freegame", quota=0.30,
                        conditions={
                            "reel_weights": {
                                self.basegame_type: {"BR0": 1},
                                self.freegame_type: {"FR0": 1},
                            },
                            "scatter_triggers": {3: 100, 4: 20, 5: 5},
                            "force_wincap": False,
                            "force_freegame": True,
                        },
                    ),
                    Distribution(
                        criteria="hunt_basegame", quota=0.70,
                        conditions={
                            "reel_weights": {self.basegame_type: {"BR0": 1}},
                            "force_wincap": False,
                            "force_freegame": False,
                        },
                    ),
                ],
            ),
            BetMode(
                name="wild_feature", cost=20.0, rtp=self.rtp, max_win=self.wincap,
                auto_close_disabled=False, is_feature=False, is_buybonus=True,
                distributions=[
                    Distribution(
                        criteria="two_wild_squares_x2", quota=1.0,
                        conditions={
                            "reel_weights": {self.basegame_type: {"BR0": 1}},
                            "force_wincap": False,
                            "force_freegame": False,
                        },
                    ),
                ],
            ),
        ]
