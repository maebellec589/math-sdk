"""Two randomly positioned single-cell Wilds for the DING DONG Wild Feature.

Exactly two feature Wilds are spawned on each feature board: the initial reveal
and every subsequent cascade board. Their positions are sampled independently
for each board. They are NOT sticky: the previous pair is removed during the
tumble before a fresh pair is spawned.
"""
from __future__ import annotations

import random

BOARD_REELS = 5
BOARD_ROWS = 6
WILD_SQUARE_COUNT = 2


def apply_two_random_wilds(board, create_symbol, rng=None):
    """Place exactly two Wild squares at distinct random cells.

    `rng` is injectable for deterministic tests. The SDK integration uses the
    Python random module unless its runtime supplies a dedicated RNG.
    """
    if len(board) != BOARD_REELS:
        raise ValueError("DING DONG Wild Feature requires exactly 5 reels")
    if any(len(reel) != BOARD_ROWS for reel in board):
        raise ValueError("DING DONG Wild Feature requires exactly 6 rows per reel")
    chooser = rng if rng is not None else random
    cells = [(reel, row) for reel in range(BOARD_REELS) for row in range(BOARD_ROWS)]
    positions = tuple(chooser.sample(cells, WILD_SQUARE_COUNT))
    for reel_index, row_index in positions:
        board[reel_index][row_index] = create_symbol("W")
    return positions


def mark_previous_feature_wilds_for_removal(board, positions):
    """Make the previous feature pair tumble away before the next random pair."""
    for reel_index, row_index in positions or ():
        board[reel_index][row_index].explode = True
