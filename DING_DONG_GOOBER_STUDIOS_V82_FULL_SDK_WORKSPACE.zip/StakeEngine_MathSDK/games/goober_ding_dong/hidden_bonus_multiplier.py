"""Persistent, uncapped multiplier progression for Mystery Hidden Free Spins.

Each positive-win board connection doubles the multiplier for the next
connection. One progression object is retained for the complete bonus.
The multiplier has no artificial ladder cap; the game's monetary win cap is
handled separately by the game engine.
"""
from __future__ import annotations

HIDDEN_MULTIPLIER_START = 2


class HiddenBonusMultiplier:
    def __init__(self, current: int = HIDDEN_MULTIPLIER_START, cap: int | None = None):
        if current < 1 or (cap is not None and cap < current):
            raise ValueError("invalid hidden bonus multiplier bounds")
        self.current = int(current)
        self.cap = None if cap is None else int(cap)
        self.connections = 0

    def record_connection(self) -> int:
        """Record one positive-win board and return the next connection multiplier."""
        self.connections += 1
        next_value = self.current * 2
        self.current = min(next_value, self.cap) if self.cap is not None else next_value
        return self.current

    def snapshot(self) -> dict:
        return {
            "multiplier": self.current,
            "connections": self.connections,
            "cap": self.cap,
        }
