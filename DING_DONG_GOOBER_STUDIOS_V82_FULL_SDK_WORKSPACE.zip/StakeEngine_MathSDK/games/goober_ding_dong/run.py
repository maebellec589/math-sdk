"""Safe DING DONG SDK entrypoint.

Run preflight and deterministic smoke tests first. Production book generation is
intentionally not enabled until all six modes have validated optimization inputs.
"""
from pathlib import Path
import subprocess
import sys

GAME_DIR = Path(__file__).resolve().parent
SDK_ROOT = GAME_DIR.parents[1]

if __name__ == "__main__":
    preflight = subprocess.run([sys.executable, str(GAME_DIR / "preflight.py")], cwd=SDK_ROOT)
    if preflight.returncode != 0:
        raise SystemExit(preflight.returncode)
    smoke = subprocess.run([sys.executable, str(GAME_DIR / "tests" / "sdk_smoke_test.py")], cwd=SDK_ROOT)
    if smoke.returncode != 0:
        raise SystemExit(smoke.returncode)
    print("Preflight and deterministic smoke tests passed.")
    print("Book generation remains disabled pending full optimization/RTP validation.")
