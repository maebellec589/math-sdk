"""SDK integration smoke test for DING DONG.
Run from the math-sdk repository root after `make setup`:
    python games/goober_ding_dong/tests/sdk_smoke_test.py
"""
import sys
from pathlib import Path

GAME_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(GAME_DIR))

from game_config import GameConfig
from gamestate import GameState


def main():
    config = GameConfig()
    assert config.num_reels == 5
    assert config.num_rows == [6, 6, 6, 6, 6]
    assert [m.get_name() for m in config.bet_modes] == [
        "base", "bonus_normal", "bonus_super", "mystery", "bonus_hunt", "wild_feature"
    ]
    state = GameState(config)
    cases = [
        ("base", "basegame"),
        ("wild_feature", "two_wild_squares_x2"),
        ("bonus_normal", "normal_10fs"),
        ("bonus_super", "super_15fs"),
        ("mystery", "mystery_empty"),
        ("mystery", "mystery_hidden_5fs"),
        ("mystery", "mystery_super_15fs"),
        ("bonus_hunt", "hunt_basegame"),
        ("bonus_hunt", "hunt_freegame"),
    ]
    for index, (mode, criteria) in enumerate(cases, start=1):
        state.betmode = mode
        state.criteria = criteria
        state.run_spin(index, simulation_seed=20261109 + index)
        assert 0 <= state.final_win <= config.wincap, (mode, criteria, state.final_win)
        print(f"PASS {mode}/{criteria}: win={state.final_win:.6f}x, fs={state.tot_fs}")
    print(f"PASS: {len(cases)} SDK game-state smoke cases")


if __name__ == "__main__":
    main()
