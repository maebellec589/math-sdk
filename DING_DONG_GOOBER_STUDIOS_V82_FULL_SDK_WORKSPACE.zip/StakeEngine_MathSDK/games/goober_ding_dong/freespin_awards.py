"""Pure Free Spins award resolver shared by the SDK adapter and unit tests.

Awards from explicitly selected buy/mystery criteria take precedence over the
natural scatter-count gate. Natural/basegame awards still require 3+ scatters.
"""
from __future__ import annotations

BOUGHT_AWARDS = {
    "normal_10fs": 10,
    "super_15fs": 15,
    "mystery_hidden_5fs": 5,
    "mystery_super_15fs": 15,
}


def resolve_freespin_award(criteria: str, scatter_count: int, gametype: str, triggers: dict) -> int:
    """Return the exact FS award for a selected criterion and observed scatters."""
    if criteria in BOUGHT_AWARDS:
        return BOUGHT_AWARDS[criteria]
    count = min(max(int(scatter_count), 0), 5)
    if count < 3:
        return 0
    awards = triggers.get(gametype, {})
    return int(awards.get(count, 0))
