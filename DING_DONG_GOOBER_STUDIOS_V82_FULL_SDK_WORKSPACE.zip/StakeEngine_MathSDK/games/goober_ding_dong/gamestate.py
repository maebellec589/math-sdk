import random
"""DING DONG Stake Engine GameState using the SDK's native Tumble pipeline.

Copy this folder into games/goober_ding_dong/ in a local math-sdk checkout.
This is an integration draft based on the current public SDK source; run the
SDK validation suite before treating it as production-ready.
"""
from game_override import GameStateOverride
from src.events.events import update_global_mult_event
from hidden_bonus_multiplier import HiddenBonusMultiplier
from wild_feature_squares import (apply_two_random_wilds, mark_previous_feature_wilds_for_removal)

FREE_SPIN_MULTIPLIERS = (2, 3, 5, 10, 25, 50)


class GameState(GameStateOverride):
    """5x6 Ways game with native SDK tumbles and free-spin cascade multipliers."""

    def run_spin(self, sim, simulation_seed=None):
        self.reset_seed(sim, simulation_seed)
        # Use the per-spin simulation seed for reproducible random Wild cells.
        self._wild_rng = random.Random(simulation_seed) if simulation_seed is not None else random
        self.repeat = True
        while self.repeat:
            self.reset_book()
            self.draw_board(emit_event=True)
            # Wild Feature: two randomly positioned single-cell Wilds are
            # spawned on the initial board and refreshed on every cascade.
            # The feature carries a guaranteed x2 multiplier for this paid spin.
            self.global_multiplier = 2 if (
                self.betmode == "wild_feature" and self.criteria == "two_wild_squares_x2"
            ) else 1
            self.evaluate_ways_board(apply_current_multiplier=True)
            self.emit_tumble_win_events()
            while self.win_data["totalWin"] > 0 and not self.wincap_triggered:
                if self.betmode == "wild_feature" and self.criteria == "two_wild_squares_x2":
                    mark_previous_feature_wilds_for_removal(
                        self.board, getattr(self, "wild_feature_positions", ())
                    )
                self.tumble_game_board()
                if self.betmode == "wild_feature" and self.criteria == "two_wild_squares_x2":
                    self.wild_feature_positions = apply_two_random_wilds(
                        self.board, self.create_symbol, rng=self._wild_rng
                    )
                    self.get_special_symbols_on_board()
                self.evaluate_ways_board(apply_current_multiplier=True)
                self.emit_tumble_win_events()
            self.set_end_tumble_event()
            self.win_manager.update_gametype_wins(self.gametype)

            if self.check_fs_condition() and self.check_freespin_entry():
                self.run_freespin_from_base()

            self.evaluate_finalwin()
            self.check_repeat()

        self.imprint_wins()

    def run_freespin(self):
        self.reset_fs_spin()
        hidden_bonus = self.criteria == "mystery_hidden_5fs"
        hidden_progression = HiddenBonusMultiplier() if hidden_bonus else None

        while self.fs < self.tot_fs and not self.wincap_triggered:
            self.update_freespin()
            self.draw_board(emit_event=True)

            if hidden_bonus:
                # One progression object spans the entire Hidden bonus session.
                self.global_multiplier = hidden_progression.current
            else:
                self.global_multiplier = FREE_SPIN_MULTIPLIERS[0]
            update_global_mult_event(self)

            self.evaluate_ways_board(apply_current_multiplier=True)
            self.emit_tumble_win_events()
            cascade_index = 0

            # Every positive-win board is one connection. For Hidden, double
            # after paying that connection; the new value applies to the next
            # tumble and carries into every remaining Free Spin.
            if hidden_bonus and self.win_data["totalWin"] > 0:
                self.global_multiplier = hidden_progression.record_connection()
                update_global_mult_event(self)

            while self.win_data["totalWin"] > 0 and not self.wincap_triggered:
                self.tumble_game_board()
                cascade_index += 1
                if hidden_bonus:
                    self.global_multiplier = hidden_progression.current
                else:
                    self.global_multiplier = FREE_SPIN_MULTIPLIERS[
                        min(cascade_index, len(FREE_SPIN_MULTIPLIERS) - 1)
                    ]
                update_global_mult_event(self)
                self.evaluate_ways_board(apply_current_multiplier=True)
                self.emit_tumble_win_events()

                if hidden_bonus and self.win_data["totalWin"] > 0:
                    self.global_multiplier = hidden_progression.record_connection()
                    update_global_mult_event(self)

            self.set_end_tumble_event()
            self.win_manager.update_gametype_wins(self.gametype)

            # Retriggers intentionally disabled until the game brief defines them.

        self.end_freespin()
